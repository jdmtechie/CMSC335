import java.util.ArrayList;
import java.util.Scanner;

/**
 * File: TheSorcerersCave.java
 * Date: 24 Jan 2016
 * @author James Moore
 * Purpose: Develop a game called The Sorcerers Cave 
 */

//Creatures make up parties in the cave and hold artifacts and 
// treasure
public class Creature extends CaveElement {
    
    ArrayList<Treasure> treasureList = new ArrayList<Treasure>();
    ArrayList<Artifact> artifactList = new ArrayList<Artifact>();
    
    int partyIndex;
    int empathy;
    int fear;
    double capacity;
    
    public int makeCreature(Scanner s) {
	s.next();
	index = s.nextInt();
	type = s.next();
	name = s.next();
	partyIndex = s.nextInt();
	empathy = s.nextInt();
	fear = s.nextInt();
	capacity = s.nextDouble();	
	return partyIndex;
    } // end makeCreature
    
    public void addTreasure(Treasure t) {
	treasureList.add(t);
    } // end addTreasure
    
    public void addArtifact(Artifact a) {
	artifactList.add(a);
    } // end addArtifact
    
    public String toString() {
	String st = "        " + name + "\n                  Artifacts: ";
	for (Artifact a: artifactList) 
	    st += a + " ";
	st += "\n                  Treasures: ";
	for (Treasure t: treasureList) 
	    st += t + " ";
	return st;
    } // end toString
} // end Creature